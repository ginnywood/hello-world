# hello-world

My name is Ginny. I am learning to magick with code words.
